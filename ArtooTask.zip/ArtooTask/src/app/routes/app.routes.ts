import { Routes } from '@angular/router';
import { pictureDetail } from '../Pages/PictureDetail.page/pictureDetail';
import { Gallery } from '../Pages/Home.page/Gallery';


export const ROUTES: Routes = [
  { path: '',component : Gallery },
  { path: 'pictureDetail', component: pictureDetail }
];
