import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppStates } from '../../services/app.service';


@Component({
    selector: 'pictureDetail',
    templateUrl:'pictureDetail.html'
  })

export class pictureDetail implements OnInit {
  public imgUrl:any;
  public edit = "../../../assets/img/if_pencil_383094.svg";
  public lat: number = 51.678418;
  public long: number = 7.809007;
  public currentState:any;
  public time:any;
  public description:any;
  public title:String;
  public showEdit:boolean = true;
  public showUpdate:boolean = false;
  constructor(public state:AppStates){

  }

  ngOnInit(){
    try{
      this.currentState = this.state.currentState;
      console.log(this.currentState)
      this.imgUrl = this.currentState.image.url;
      this.lat = parseFloat(this.currentState.image.lat);
      this.long = parseFloat(this.currentState.image.long);
      this.time = this.getDate(this.currentState.image.time);
      this.description = this.currentState.image.description;
    }catch(err){
      console.log(err)
    }
  }

  getDate(date){
    console.log()
    let newDate  = new Date(parseInt(date));
    console.log(newDate)
    let split = newDate.toString().split(' ');
    return split[2]+" "+split[1]+" "+split[3];
  }
  
  editTitle(){
    this.showEdit = false;
    this.showUpdate = true;
  }

  updateTitle(title){
    this.currentState.image.name = title
    this.showEdit = true;
    this.showUpdate = false;
  }

  updateLatLong(lat,long){
    if(parseFloat(lat) && parseFloat(long)){
      this.currentState.image.lat = this.lat = parseFloat(lat);
      this.currentState.image.long = this.long = parseFloat(long);
      console.log(this.lat)
      console.log(this.long)
    }
  }

}