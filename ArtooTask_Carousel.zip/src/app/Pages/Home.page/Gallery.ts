import { Component, OnInit, ViewEncapsulation} from '@angular/core';
import { Routes ,Router} from '@angular/router';
import {DataService} from '../../services/Data.service';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AppStates } from '../../services/app.service';

@Component({
    selector: 'Gallery',
    templateUrl:'Gallery.html'
  })

export class Gallery implements OnInit {

    public pagesList:any;
    public currentPage:any;
    public mapImg:any;
    public pageId:number;
    public config: SwiperOptions;
    public showSlider:boolean = true;
    public isGrid:boolean = false;

    constructor(public dataservice:DataService,private sanitizer: DomSanitizer,public router: Router,public states: AppStates){}
  
    public ngOnInit() {

        if(this.router.url === '/grid'){
            this.isGrid = true;
        }

        this.pagesList = this.dataservice.pagesList;
        if(this.states.currentState){
            console.log(this.states.currentState)
            this.pageId = this.states.currentState.id;    
            this.currentPage = this.pagesList.filter(page=>{ if(page.id == this.pageId) return page})[0].images;
        }else{
            this.currentPage = this.pagesList[0].images;
            this.pageId = this.pagesList[0].id;    
        }

        this.config = {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            spaceBetween: 0
        };
    }

    getPages(page){
        this.showSlider = false;
        console.log(page)
        this.pageId = page.id;
        this.currentPage = page.images;
        this.showSlider = true;
    }

    goToDetail(image,id){
        this.router.navigate(['/pictureDetail']);
        this.states.currentState = {id:id,image:image};
    }
  
}