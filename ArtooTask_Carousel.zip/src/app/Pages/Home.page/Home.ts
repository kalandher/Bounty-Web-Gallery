import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'Home',
    templateUrl:'Home.html'
  })

export class Home implements OnInit {
  
    public ngOnInit() {
    }
  
}