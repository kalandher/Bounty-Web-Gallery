import { Component, OnInit,Input, ViewEncapsulation, ViewChild} from '@angular/core';
import { Routes ,Router} from '@angular/router';
import {DataService} from '../../services/Data.service';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AppStates } from '../../services/app.service';
import { SwiperComponent } from 'angular2-useful-swiper/lib/swiper.module';

@Component({
    selector: 'Gallery-component',
    templateUrl:'Gallery-component.html'
  })

export class GalleryComponent {
    @Input('activePage') currentPage;
    @Input('pageId') pageId;
    public pagesList:any;
    public mapImg:any;
    public config: SwiperOptions;
    // public swiper: Swiper;
    public showSlider:boolean = false;
    public swiper:Swiper;

    constructor(public dataservice:DataService,private sanitizer: DomSanitizer,public router: Router,public states: AppStates){
    }

    ngOnChanges(changes){
        this.showSlider = false;
        this.currentPage = changes['currentPage'].currentValue;
        let selectedImageIndex = 0;
        if(this.states.currentState){
            selectedImageIndex = this.currentPage.indexOf(this.states.currentState.image)
        }
        this.pageId = changes['pageId'].currentValue;
        this.config = {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            spaceBetween: 0,
            preloadImages:true,
            updateOnImagesReady:true,
            initialSlide: selectedImageIndex
        };
        setTimeout(f=>{
            this.showSlider = true;
        },1)
    }

    goToDetail(image,id){
        this.router.navigate(['/pictureDetail']);
        this.states.currentState = {id:id,image:image};
    }
}