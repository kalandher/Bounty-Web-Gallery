import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DataService {



    public pagesList = [
        {
            'id':1,
            "name":"Mountains",
            "images":[{
                "name":"Cloudy Scotland","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392088.jpg",'time':'105555686556','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Pixabay","lat":"40.9645293","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392052.jpg",'time':'234234234324','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"Telluride Community.","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392060.jpg",'time':'23423423423','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Bend Scotland","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392069.jpg",'time':'4234234324234','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Telluride","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392077.jpg",'time':'12248555665','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Coeur d'Alene","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392084.jpg",'time':'105555686556','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Lewisburg","lat":"40.9645293","long":"-76.8844101","url":"../../../assets/img/images/cloudy-scotland-1392116.jpg",'time':'105555686556','description':"The Atlantic at Parkridge is a brand new apartment community. Stop in at our location in Irmo, SC and see what we have available."
            },{
                "name":"Landing at Ellis Island ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626155.jpeg",'time':'10553455556','description':"Former FBI director James Comey clapped back at President Trump Saturday in a fiery tweet that said the American people can judge for themselves who is honorable in government. Mr. President, the American people will hear my story very soon. And they can judge for themselves who is honorable man"
            },{
                "name":"Asheville","lat":"56.490671","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'124865656','description':"The two waterways are often jointly and simply referred to as the St. Lawrence Seaway, since the Great Lakes, together with the St. Lawrence River, comprise a single navigable body of freshwater linking the Atlantic Ocean to the continental interior. Shipping channels separate upbound traffic from downbound traffic."
            },{
                "name":"Cloudy Scotland","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047383.jpeg",'time':'5345345345','description':"Former FBI director James Comey clapped back at President Trump Saturday in a fiery tweet that said the American people can judge for themselves who is honorable in government. Mr. President, the American people will hear my story very soon. And they can judge for themselves who is honorable an"
            },{
                "name":"Atlantic Liner","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626155.jpeg",'time':'435345435','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Park City","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392109.jpg",'time':'1254862158','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means 'Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"Lewisburg","lat":"40.9645293","long":"-76.8844101","url":"../../../assets/img/images/cloudy-scotland-1392116.jpg",'time':'105555686556','description':"The Atlantic at Parkridge is a brand new apartment community. Stop in at our location in Irmo, SC and see what we have available."
            },{
                "name":"Sugar Hill","lat":"44.215341","long":"-71.7995321","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'23423423423','description':"Atlantic was a steamboat that sank on Lake Erie after a collision with the steamer Ogdensburg on 20 August 1852, with the loss of at least 150 but perhaps as many as 300 lives. The loss of life made this disaster, in terms of loss of life from the sinking of a single vessel, the fifth-worst tragedy in the history of the Great Lakes."
            },{
                "name":"Ellis Island ferry","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'105555686556','description':"North America is a continent entirely within the Northern Hemisphere and almost all within the Western Hemisphere; it is also considered by some to be a northern subcontinent of the Americas. It is bordered to the north by the Arctic Ocean, to the east by the Atlantic Ocean, to the west and south by the Pacific Ocean"
            },{
                "name":"Welcome to the land","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'4234234234','description':"America is a continent comprising of 2 landmasses- North America and South America. Inside North America lies a very powerful and famous country called the 'United States of America'. Technically, the word American SHOULD refer to any person."
            },{
                "name":"Woodstock","lat":"34.1014873","long":"-84.5193754","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'234324324','description':"Toxic Dust From a Dying California Lake. The shrinking Salton Sea is now a major source of air pollution—and no one seems to know how to stop it from getting worse. A dead fish in the dried bed of the Salton Sea Damian Dovarganes"
            },{
                "name":"Eureka Springs","lat":"40.7143528","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392133.jpg",'time':'234234234','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            }]
        },{
            'id':2,
            "name":"Arts and Crafts",
            "images":[{
                "name":"Welcome to the land Liner","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-42149.jpeg",'time':'105555686556','description':"Americans are citizens of the United States of America. The country is home to people of many different national origins. As a result, many Americans do not equate their nationality with ethnicity, but with citizenship and allegiance."
            },{
                "name":"Park City","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392109.jpg",'time':'1254862158','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means 'Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"Lewisburg","lat":"40.9645293","long":"-76.8844101","url":"../../../assets/img/images/cloudy-scotland-1392116.jpg",'time':'105555686556','description':"The Atlantic at Parkridge is a brand new apartment community. Stop in at our location in Irmo, SC and see what we have available."
            },{
                "name":"Landing at Ellis Island ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626155.jpeg",'time':'10553455556','description':"Former FBI director James Comey clapped back at President Trump Saturday in a fiery tweet that said the American people can judge for themselves who is honorable in government. Mr. President, the American people will hear my story very soon. And they can judge for themselves who is honorable man"
            },{
                "name":"Ellis Island","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626631.jpeg",'time':'345345345','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Awaiting examination, Ellis Island ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-688694.jpeg",'time':'105555686556','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Examination Hall","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1033849.jpeg",'time':'345345345','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"The Evolution of the Conservation Movement","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'105555686556','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Cloudy Scotland","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047383.jpeg",'time':'5345345345','description':"Former FBI director James Comey clapped back at President Trump Saturday in a fiery tweet that said the American people can judge for themselves who is honorable in government. Mr. President, the American people will hear my story very soon. And they can judge for themselves who is honorable an"
            },{
                "name":"Atlantic Liner","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626155.jpeg",'time':'435345435','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"land of freedom","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047349.jpeg",'time':'23423432423','description':"All 23 independent countries of North America, including island states in the Caribbean. Always up-to-date and accurate information."
            },{
                "name":"Ellis Island","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'234234324','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer"
            },{
                "name":"Examination Hall","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'2343244324','description':"North America is one of two continents named after the Italian explorer Amerigo Vespucci, with a surface area of 24,221,490km² (9,351,969 square miles). It's in the northern hemisphere, between the Pacific Ocean"
            },{
                "name":"Ellis Island ferry","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'105555686556','description':"North America is a continent entirely within the Northern Hemisphere and almost all within the Western Hemisphere; it is also considered by some to be a northern subcontinent of the Americas. It is bordered to the north by the Arctic Ocean, to the east by the Atlantic Ocean, to the west and south by the Pacific Ocean"
            },{
                "name":"Welcome to the land","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'4234234234','description':"America is a continent comprising of 2 landmasses- North America and South America. Inside North America lies a very powerful and famous country called the 'United States of America'. Technically, the word American SHOULD refer to any person."
            },{
                "name":"Welcome to the land","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'105555686556','description':"All 23 independent countries of North America, including island states in the Caribbean. Always up-to-date and accurate information."
            },{
                "name":"Cloudy Scotland","lat":"34.1014873","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-42149.jpeg",'time':'1055586556','description':"There are seven countries in Central America: Guatemala, Belize, Honduras, El Salvador, Nicaragua, Honduras, and Panama."
            },{
                "name":"Woodstock","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-297824.jpeg",'time':'234234324324','description':"The USA is the world's foremost economic and military power, with global interests and an unmatched global reach. America's gross domestic product accounts for close to a quarter of the world total, and its military budget is reckoned to be almost as much as the rest of the world's defence spending put together."
            },]
        },
        {
            'id':3,
            "name":"Science and Ficton",
            "images":[{
                    "name":"Park City","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392109.jpg",'time':'1254862158','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means 'Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"Lewisburg","lat":"40.9645293","long":"-76.8844101","url":"../../../assets/img/images/cloudy-scotland-1392116.jpg",'time':'105555686556','description':"The Atlantic at Parkridge is a brand new apartment community. Stop in at our location in Irmo, SC and see what we have available."
            },{
                "name":"Waiting for Ellis Island ferry ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-297824.jpeg",'time':'23423423','description':"Americans are citizens of the United States of America. The country is home to people of many different national origins. As a result, many Americans do not equate their nationality with ethnicity, but with citizenship and allegiance."
            },{
                "name":"Welcome to the land of freedom","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-594685.jpeg",'time':'345345','description':"Collection junior. Et pour répondre à tous vos désirs, American People décline sa collection homme en junior ! Habillez votre mini-vous, comme vous ! Découvrir. Automne-Hiver. American People, la marque de référence Française en terme de vêtements spotswears branchés pour homme et pour enfant"
            },{
                "name":"Sugar Hill","lat":"44.215341","long":"-71.7995321","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'23423423423','description':"Atlantic was a steamboat that sank on Lake Erie after a collision with the steamer Ogdensburg on 20 August 1852, with the loss of at least 150 but perhaps as many as 300 lives. The loss of life made this disaster, in terms of loss of life from the sinking of a single vessel, the fifth-worst tragedy in the history of the Great Lakes."
            },{
                "name":"Woodstock","lat":"34.1014873","long":"-84.5193754","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'234324324','description':"Toxic Dust From a Dying California Lake. The shrinking Salton Sea is now a major source of air pollution—and no one seems to know how to stop it from getting worse. A dead fish in the dried bed of the Salton Sea Damian Dovarganes"
            },{
                "name":"Ellis Island","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626631.jpeg",'time':'345345345','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Bend Scotland","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392069.jpg",'time':'4234234324234','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Eureka Springs","lat":"40.7143528","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392133.jpg",'time':'234234234','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Coeur d'Alene","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392084.jpg",'time':'105555686556','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Asheville","lat":"56.490671","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'124865656','description':"The two waterways are often jointly and simply referred to as the St. Lawrence Seaway, since the Great Lakes, together with the St. Lawrence River, comprise a single navigable body of freshwater linking the Atlantic Ocean to the continental interior. Shipping channels separate upbound traffic from downbound traffic."
            },{
                "name":"Park City","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392109.jpg",'time':'1254862158','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means 'Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"Lewisburg","lat":"40.9645293","long":"-76.8844101","url":"../../../assets/img/images/cloudy-scotland-1392116.jpg",'time':'105555686556','description':"The Atlantic at Parkridge is a brand new apartment community. Stop in at our location in Irmo, SC and see what we have available."
            },{
                "name":"Sugar Hill","lat":"44.215341","long":"-71.7995321","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'23423423423','description':"Atlantic was a steamboat that sank on Lake Erie after a collision with the steamer Ogdensburg on 20 August 1852, with the loss of at least 150 but perhaps as many as 300 lives. The loss of life made this disaster, in terms of loss of life from the sinking of a single vessel, the fifth-worst tragedy in the history of the Great Lakes."
            },{
                "name":"Woodstock","lat":"34.1014873","long":"-84.5193754","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'234324324','description':"Toxic Dust From a Dying California Lake. The shrinking Salton Sea is now a major source of air pollution—and no one seems to know how to stop it from getting worse. A dead fish in the dried bed of the Salton Sea Damian Dovarganes"
            },{
                "name":"Eureka Springs","lat":"40.7143528","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392133.jpg",'time':'234234234','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Examination Hall","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'2343244324','description':"North America is one of two continents named after the Italian explorer Amerigo Vespucci, with a surface area of 24,221,490km² (9,351,969 square miles). It's in the northern hemisphere, between the Pacific Ocean"
            },{
                "name":"Ellis Island ferry","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'105555686556','description':"North America is a continent entirely within the Northern Hemisphere and almost all within the Western Hemisphere; it is also considered by some to be a northern subcontinent of the Americas. It is bordered to the north by the Arctic Ocean, to the east by the Atlantic Ocean, to the west and south by the Pacific Ocean"
            }]
        },{
            'id':4,
            "name":"Hotels and Places",
            "images":[{
                "name":"Welcome to the land Liner","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-42149.jpeg",'time':'105555686556','description':"Americans are citizens of the United States of America. The country is home to people of many different national origins. As a result, many Americans do not equate their nationality with ethnicity, but with citizenship and allegiance."
            },{
                "name":"Waiting for Ellis Island ferry ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-297824.jpeg",'time':'23423423','description':"Americans are citizens of the United States of America. The country is home to people of many different national origins. As a result, many Americans do not equate their nationality with ethnicity, but with citizenship and allegiance."
            },{
                "name":"Welcome to the land of freedom","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-594685.jpeg",'time':'345345','description':"Collection junior. Et pour répondre à tous vos désirs, American People décline sa collection homme en junior ! Habillez votre mini-vous, comme vous ! Découvrir. Automne-Hiver. American People, la marque de référence Française en terme de vêtements spotswears branchés pour homme et pour enfant"
            },{
                "name":"Landing at Ellis Island ","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626155.jpeg",'time':'10553455556','description':"Former FBI director James Comey clapped back at President Trump Saturday in a fiery tweet that said the American people can judge for themselves who is honorable in government. Mr. President, the American people will hear my story very soon. And they can judge for themselves who is honorable man"
            },{
                "name":"Ellis Island","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-626631.jpeg",'time':'345345345','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer."
            },{
                "name":"Bend Scotland","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392069.jpg",'time':'4234234324234','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Telluride","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392077.jpg",'time':'12248555665','description':"A mountain is a large landform that stretches above the surrounding land in a limited area, usually in the form of a peak. A mountain is generally steeper than a hill. Mountains are formed through tectonic forces or volcanism. These forces can locally raise the surface of the earth."
            },{
                "name":"Coeur d'Alene","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392084.jpg",'time':'105555686556','description':"The Great Lakes are now home to 186 non-native species. None has been more devastating than the Junior Mint–sized zebra and quagga mussels, two closely related mollusks native to the Black and Caspian Seas. A college kid on a field trip in the late 1980s was the first to discover them in the Great Lakes."
            },{
                "name":"Asheville","lat":"56.490671","long":"-74.0059731","url":"../../../assets/img/images/cloudy-scotland-1392103.jpg",'time':'124865656','description':"The two waterways are often jointly and simply referred to as the St. Lawrence Seaway, since the Great Lakes, together with the St. Lawrence River, comprise a single navigable body of freshwater linking the Atlantic Ocean to the continental interior. Shipping channels separate upbound traffic from downbound traffic."
            },{
                "name":"Park City","lat":"40.7143528","long":"-4.202646","url":"../../../assets/img/images/cloudy-scotland-1392109.jpg",'time':'1254862158','description':"Ontario, Canada's most populous province, was named for the lake. In the Huron language, the name Ontarí'io means 'Lake of Shining Waters. Its primary inlet is the Niagara River from Lake Erie. The last in the Great Lakes chain, Lake Ontario serves as the outlet to the Atlantic Ocean via the Saint Lawrence River."
            },{
                "name":"land of freedom","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047349.jpeg",'time':'23423432423','description':"All 23 independent countries of North America, including island states in the Caribbean. Always up-to-date and accurate information."
            },{
                "name":"Ellis Island","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'234234324','description':"North America: Geographical treatment of North America, including maps and statistics as well as a survey of its geologic history, land, people, and economy. It occupies the northern portion of the 'New World.' North America, the world's third largest continent, lies mainly between the Arctic Circle and the Tropic of Cancer"
            },{
                "name":"Examination Hall","lat":"44.215341","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'2343244324','description':"North America is one of two continents named after the Italian explorer Amerigo Vespucci, with a surface area of 24,221,490km² (9,351,969 square miles). It's in the northern hemisphere, between the Pacific Ocean"
            },{
                "name":"Ellis Island ferry","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047540.jpeg",'time':'105555686556','description':"North America is a continent entirely within the Northern Hemisphere and almost all within the Western Hemisphere; it is also considered by some to be a northern subcontinent of the Americas. It is bordered to the north by the Arctic Ocean, to the east by the Atlantic Ocean, to the west and south by the Pacific Ocean"
            },{
                "name":"Welcome to the land","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047870.jpeg",'time':'4234234234','description':"America is a continent comprising of 2 landmasses- North America and South America. Inside North America lies a very powerful and famous country called the 'United States of America'. Technically, the word American SHOULD refer to any person."
            },{
                "name":"Welcome to the land","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-1047328.jpeg",'time':'105555686556','description':"All 23 independent countries of North America, including island states in the Caribbean. Always up-to-date and accurate information."
            },{
                "name":"Cloudy Scotland","lat":"34.1014873","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-42149.jpeg",'time':'1055586556','description':"There are seven countries in Central America: Guatemala, Belize, Honduras, El Salvador, Nicaragua, Honduras, and Panama."
            },{
                "name":"Woodstock","lat":"56.490671","long":"-4.202646","url":"../../../assets/img/images/pexels-photo-297824.jpeg",'time':'234234324324','description':"The USA is the world's foremost economic and military power, with global interests and an unmatched global reach. America's gross domestic product accounts for close to a quarter of the world total, and its military budget is reckoned to be almost as much as the rest of the world's defence spending put together."
            },]
        }
    ]
  
}


